// // Chapter--1
// // QUECTION--1
// alert("Hello-world")
// // QUECTION--2
// alert("ERROR! Pleace enter a valid anumber")
// // QUECTION--3
// alert("welcomr to js land\nhappy coading")
// // QUECTION--4
// alert('welcome to js land')
// // QUECTION--5
// console.log('Hello.. i can run Js through my web browser')

//     // CHAPTER--2
// // QUECTION-1
// var user_name;
// user_name='maaz';
// alert(user_name)
// // QUECTION--2
// var first_name = 'maaz'
// var last_name = 'ahmed'
// var full_name = first_name+last_name
// alert(full_name)
// // QUECTION--3
// var message='HELLO_WORLD'
// alert(message)
// // QUECTION--4
// var Bio_data = '15 year old'
// alert(Bio_data)
// // QUECTION--5
// var variable=('welcome to my website')
// alert(variable)
// // QUECTION--6
// var email ='maaza@gmail.com'
// alert(email)
// QUECTION--7
var Js = 'A smarter way to learn java script'
alert('I am trying to learn from the book '+Js )
// QUECTION--8
document.write('YAH! I CAN WRUTE CONTENT THROUGH JS')

        // CHAPTER--3
// QUECTION-1
var age='I am 15 year old'
alert(age)
// QUECTION--2
var initialize=('you have visited this site 14 times')
alert(initialize)
// QUECTION--3
var birth = 'my birth year is 2006\n data type of my declear variable is number '
alert(birth)
// QUECTION--4
document.write('john doe <b>T shirt (s) on XYZ clothing store')

//      CHAPTER--4
// QUECTION-1
var a=maaz; b=20; c=30;
               // QUECTION--2
// LEGAL--JS--ROLE
